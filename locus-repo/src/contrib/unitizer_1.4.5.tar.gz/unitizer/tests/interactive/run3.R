library(unitizer)
unitize("tests/interactive/unitizer/assign.R")
unitize("tests/interactive/unitizer/nested.R")
unitize("tests/interactive/unitizer/misc.R")
