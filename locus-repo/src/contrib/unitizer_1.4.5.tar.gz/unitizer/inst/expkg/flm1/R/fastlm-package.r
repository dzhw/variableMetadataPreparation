#' fastlm
#'
#' @name fastlm
#' @docType package
NULL
