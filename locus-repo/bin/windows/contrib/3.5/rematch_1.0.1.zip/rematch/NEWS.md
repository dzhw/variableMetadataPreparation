
# 1.0.1

* Make `R CMD check` work when `testthat` is not available.

* Fixed a bug with group capture when `text` is a scalar.

# 1.0.0

First public release.
