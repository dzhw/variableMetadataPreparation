a <- 1
b <- 2
a <- runif(20)
a + b
c <- a + b
b <- "hello"
b
sample(1:10)
