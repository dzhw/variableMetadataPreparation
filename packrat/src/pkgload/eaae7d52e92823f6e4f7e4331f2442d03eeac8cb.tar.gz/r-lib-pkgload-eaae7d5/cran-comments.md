This is a re-submission

Compared to the past submission I have changed the wording to avoid a note. My
apologies for the NOTE, I misinterpreted the meaning of the previous NOTE.

>  The Description field should not start with the package name,
     'This package' or similar

Originally I had pkgload first in the Description, and interpreted the note as
suggesting to use 'This package' instead. I now see it was listing
possibilities to avoid, my apologies.

## Test environments
* local OS X install, R 3.4.4
* ubuntu 14.04 (on travis-ci), R 3.5.0
* win-builder (devel and release)

## R CMD check results

0 errors | 0 warnings | 1 note

* This is a new release.
