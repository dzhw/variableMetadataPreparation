# should fail normally, but return TRUE if run in fastlm
library(utzflm)
hidden_fun()
