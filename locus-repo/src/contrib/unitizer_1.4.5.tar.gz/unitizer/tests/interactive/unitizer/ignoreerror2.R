TRUE
xx <- booboo # error on assign
xx
yy <- boo    # this causes an error, but should only be shown when there are non-ignored events that affect unitizer
FALSE
6
7
