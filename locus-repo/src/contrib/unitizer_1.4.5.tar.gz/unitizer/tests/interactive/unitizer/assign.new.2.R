# see assign.new.R

unitizer_sect("Section 1", {
  TRUE
  runif(10)
  1 + 1
} )

y <- 23 # this should not cause this section to show up
