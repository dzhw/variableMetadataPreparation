# Tests to check see if deleted tests work as expected

unitizer_sect("basic tests", {
  1 + 1
  TRUE
})
