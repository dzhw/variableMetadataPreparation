library(testthat)
test_check("rprintf")
