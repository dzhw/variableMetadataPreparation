x = 1

getx = function () x

import('./circular_b')

x = 2
