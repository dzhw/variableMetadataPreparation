cat('a/__init__.r\n')

which = function () 'nested/a'
