e <- 50
stop("Boom!")
g <- 32
