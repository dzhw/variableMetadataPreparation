unitizer_sect("Compare Returns False", compare=identical, {
  1L
  runif(3)
} )
unitizer_sect("I'm an empty section", details="this is just on of those tests that I had noted to myself to do")
unitizer_sect("Another empty section", details="this is just on of those tests that I had noted to myself to do", {})
