foo <- 1

head_mtcars <- head(mtcars2)
