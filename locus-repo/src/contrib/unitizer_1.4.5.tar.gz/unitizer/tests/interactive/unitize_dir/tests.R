1 + 1
print("heya")
stop("wow")   # see how a stop works
matrix(runif(21), nrow=3)
warning("this is a warning")
