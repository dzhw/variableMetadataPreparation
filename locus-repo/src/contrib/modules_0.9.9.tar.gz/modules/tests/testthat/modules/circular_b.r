a = import('./circular_a')

x = a$getx()

getx = function () x
