# File used to build a trivial unitizer for tests

TRUE
x <- 1 + 1
x + 2
y <- x
y * x
y / x + 2
