cat('a/b/c/__init__.r\n')
