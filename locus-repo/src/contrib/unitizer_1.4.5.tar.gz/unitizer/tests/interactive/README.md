## Interactive Tests

This tests are not intended to be run during R CMD check.  Rather, they are here
to test the interactive features of `unitizer` manually.  Until we come up with
some way to automatically test the interactive stuff, we're stuck with this.
